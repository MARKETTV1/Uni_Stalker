# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os
import stat
import json
import re
import logging
import requests
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.Label import Label
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigText, getConfigListEntry
from Components.Input import Input
from Tools.Directories import fileExists

# Importer UStalker_Live_Categories - ajustez selon la structure réelle
# Assurez-vous que live.py existe et contient la classe UStalker_Live_Categories
try:
    from live import UStalker_Live_Categories
    LIVE_IMPORTED = True
except ImportError:
    try:
        from .live import UStalker_Live_Categories
        LIVE_IMPORTED = True
    except ImportError:
        LIVE_IMPORTED = False
        # Classe factice si live.py n'est pas disponible
        class UStalker_Live_Categories:
            def __init__(self, session, server, genre_id=None, bouquet_title=None):
                session.open(MessageBox, "Module Live TV non disponible.", MessageBox.TYPE_ERROR)

# Setup logging
logging.basicConfig(
    level=logging.DEBUG,
    filename='/tmp/stalker_manager.log',
    filemode='a',
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Déterminer le chemin du plugin
PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))

# Chemin vers le fichier de configuration JSON - Utiliser le même chemin que dans plugin.py
STALKER_JSON_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Uni_Stalker/Servers/Stalker.json"


def load_servers_from_json():
    """Charge les serveurs Stalker depuis le fichier JSON."""
    servers = []
    if fileExists(STALKER_JSON_PATH):
        try:
            with open(STALKER_JSON_PATH, "r") as f:
                servers = json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            logging.error(f"[Stalker] Error loading servers: {str(e)}")
    # Convertir le format de données du plugin principal vers le format attendu par StalkerManager
    # Dans ce cas, les formats sont identiques, donc pas besoin de conversion
    # Mais on peut ajouter une vérification de type
    if not isinstance(servers, list):
        servers = []
    return servers


def save_servers_to_json(servers):
    """Sauvegarde les serveurs Stalker dans le fichier JSON."""
    try:
        # S'assurer que le répertoire existe
        os.makedirs(os.path.dirname(STALKER_JSON_PATH), exist_ok=True)
        with open(STALKER_JSON_PATH, "w") as f:
            json.dump(servers, f, indent=4)
        os.chmod(STALKER_JSON_PATH, stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)
        return True
    except (json.JSONDecodeError, IOError) as e:
        logging.error(f"[Stalker] Error saving servers: {str(e)}")
        return False


def migrate_old_config():
    """Migre les anciennes configurations si nécessaire."""
    try:
        if hasattr(config.plugins, 'xtreamstalker') and config.plugins.xtreamstalker.servers.value:
            old_servers = json.loads(config.plugins.xtreamstalker.servers.value)
            if old_servers and not fileExists(STALKER_JSON_PATH):
                # Convertir le format si nécessaire
                converted_servers = []
                for server in old_servers:
                    if isinstance(server, dict) and 'name' in server and 'url' in server and 'mac' in server:
                        converted_server = {
                            "SERVER_NAME": server.get("name", ""),
                            "SERVER_HOST": server.get("url", ""),
                            "ADRESS_MAC": server.get("mac", "")
                        }
                        converted_servers.append(converted_server)
                    else:
                        # Si le format est déjà correct ou inconnu, on le garde tel quel
                        converted_servers.append(server)

                if save_servers_to_json(converted_servers):
                    config.plugins.xtreamstalker.servers.value = "[]"
                    config.plugins.xtreamstalker.servers.save()
                    logging.info("Old configuration migrated successfully")
                else:
                    logging.error("Failed to migrate old configuration")
    except Exception as e:
        logging.error(f"Error during config migration: {str(e)}")


migrate_old_config()


class StalkerManagerScreen(Screen):
    """Écran pour gérer les serveurs Stalker."""
    skin = """
        <screen position="center,center" size="1200,750" title="Stalker Manager" backgroundColor="#8b008b">
            <widget name="list" position="100,120" font="Regular;30" itemHeight="40" size="1000,480" backgroundColor="#8b008b"/>
            <eLabel text="Add" position="100,650" size="150,40" font="Regular;30" halign="center" valign="center" backgroundColor="green" />
            <eLabel text="Exit" position="300,650" size="150,40" font="Regular;30" halign="center" valign="center" backgroundColor="red" />
            <widget name="status" position="100,50" size="1000,40" font="Regular;35" itemHeight="40" halign="center" backgroundColor="blue"/>
        </screen>
    """

    def __init__(self, session):
        """Initialise l'écran de gestion des serveurs."""
        Screen.__init__(self, session)
        self.session = session
        self["list"] = MenuList([])
        self["status"] = Label("Gestion des serveurs Stalker")
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "green": self.addServer,
            "red": self.close,
            "cancel": self.close,
            "ok": self.openServer
        }, -2)
        self.servers = load_servers_from_json()
        self.updateList()

    def updateList(self):
        """Met à jour la liste des serveurs affichés dans le format: 1- SERVER_NAME: SERVER_HOST/?mac=ADRESS_MAC."""
        listItems = []
        for index, server in enumerate(self.servers, start=1):
            display_name = f"{index}- {server.get('SERVER_NAME', 'Serveur sans nom')}: {server.get('SERVER_HOST', 'N/A')}?mac={server.get('ADRESS_MAC', 'N/A')}"
            listItems.append(display_name)
        self["list"].setList(listItems)

    def addServer(self):
        """Ouvre l'écran pour ajouter un nouveau serveur."""
        # Utiliser le même format que dans plugin.py
        temp_server = {
            "SERVER_NAME": "",
            "SERVER_HOST": "http://host.com:port/c/",
            "ADRESS_MAC": "00:1A:79:AA:BB:99"
        }
        self.session.openWithCallback(self.serverAdded, EditServerDetailsScreen, temp_server)

    def openServer(self):
        """Ouvre l'écran du portail pour le serveur sélectionné."""
        selected_index = self["list"].getSelectedIndex()
        if 0 <= selected_index < len(self.servers):
            self.session.open(PortalServersScreen, self.servers[selected_index])


    def serverAdded(self, server):
        """Callback pour ajouter un nouveau serveur."""
        if server:
            self.servers.append(server)
            if save_servers_to_json(self.servers):
                self["status"].setText(f"Serveur {server['SERVER_NAME']} ajouté")
            else:
                self["status"].setText("Erreur sauvegarde!")
            self.updateList()


class BouquetScreen(Screen):
    """Écran pour afficher les bouquets du serveur Stalker sélectionné."""
    skin = """
        <screen position="center,center" size="1200,750" title="Bouquets" backgroundColor="#8b008b">
            <widget name="bouquet_list" position="50,120" size="1100,480" itemHeight="45" backgroundColor="#003161" transparent="1" scrollbarMode="showOnDemand" font="Regular;28"/>
            <eLabel text="Select" position="140,660" size="190,40" font="Bold;30" halign="center" valign="center" backgroundColor="green" foregroundColor="white"/>
            <eLabel text="Back" position="380,660" size="190,40" font="Bold;30" halign="center" valign="center" backgroundColor="red" foregroundColor="white"/>
            <widget name="status" position="50,50" size="1100,40" font="Bold;30" halign="center" backgroundColor="blue" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session, server):
        """Initialise l'écran des bouquets."""
        Screen.__init__(self, session)
        self.session = session
        # Adapter le format de server pour être compatible avec PortalServersScreen
        # Utiliser le format du plugin principal
        self.server = server
        self.host = self.server["SERVER_HOST"].rstrip('/c')
        self.mac = self.server["ADRESS_MAC"]
        self.base_url = f"{self.host}/portal.php"
        self.bouquets = []
        self["bouquet_list"] = MenuList([])
        self["status"] = Label("Chargement des bouquets...")
        self["key_green"] = StaticText("Sélectionner")
        self["key_red"] = StaticText("Retour")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.selectBouquet,
            "green": self.selectBouquet,
            "red": self.close,
            "cancel": self.close
        }, -1)
        self.loadBouquets()

    def loadBouquets(self):
        """Charge les bouquets depuis l'API Stalker."""
        try:
            headers = {"Cookie": f"mac={self.mac}"}
            endpoints = [
                ("get_genres", f"{self.base_url}?type=itv&action=get_genres"),
                ("get_categories", f"{self.base_url}?type=itv&action=get_categories"),
                ("get_channel_groups", f"{self.base_url}?type=itv&action=get_channel_groups")
            ]
            bouquets_data = None
            raw_response = None
            for action, url in endpoints:
                try:
                    response = requests.get(url, headers=headers, timeout=10)
                    response.raise_for_status()
                    raw_response = response.text
                    logging.debug(f"{action} raw response: {raw_response}")
                    data = response.json()
                    bouquets_data = data.get('js', []) or data.get('data', []) or data.get('categories', [])
                    if bouquets_data:
                        logging.debug(f"Found bouquets in {action}: {len(bouquets_data)} items")
                        break
                except (requests.RequestException, json.JSONDecodeError) as e:
                    logging.error(f"Error in {action}: {str(e)}, response: {raw_response}")
                    continue

            if not bouquets_data:
                self["status"].setText("Aucun bouquet disponible")
                logging.warning("No bouquets returned from any endpoint")
                # Fallback: parse response as strings
                try:
                    # Correction: split sur '\n' au lieu de ''
                    lines = raw_response.strip().split('\n')
                    self.bouquets = [(line, {'title': line, 'id': None}) for line in lines if line.strip()]
                    if self.bouquets:
                        self.updateList()
                        self["status"].setText(f"{len(self.bouquets)} bouquets chargés (mode secours)")
                    else:
                        self["status"].setText("Aucun bouquet disponible (mode secours)")
                    return
                except Exception as e:
                    self["status"].setText(f"Erreur traitement réponse: {str(e)}")
                    logging.error(f"Fallback parsing failed: {str(e)}")
                    return

            # Handle different response formats
            self.bouquets = []
            for b in bouquets_data:
                if isinstance(b, dict):
                    title = b.get('title', 'Unknown')
                    genre_id = b.get('id') or b.get('genre_id') or b.get('category_id')
                    metadata = {k: v for k, v in b.items() if k not in ['title', 'id', 'genre_id', 'category_id']}
                else:
                    title = str(b)
                    genre_id = None
                    metadata = {}
                self.bouquets.append((title, {'title': title, 'id': genre_id, 'metadata': metadata}))

            logging.debug(f"Bouquets loaded: {[(b[0], b[1]['id'], b[1]['metadata']) for b in self.bouquets]}")
            self.updateList()
            self["status"].setText(f"{len(self.bouquets)} bouquets chargés")
        except Exception as e:
            self["status"].setText(f"Erreur chargement bouquets: {str(e)}")
            logging.error(f"Error loading bouquets: {str(e)}", exc_info=True)

    def updateList(self):
        """Met à jour la liste des bouquets."""
        self["bouquet_list"].setList([b[0] for b in self.bouquets])

    def selectBouquet(self):
        """Ouvre les chaînes du bouquet sélectionné."""
        selected = self["bouquet_list"].getCurrent()
        if selected:
            bouquet = next((b[1] for b in self.bouquets if b[0] == selected), None)
            if bouquet:
                try:
                    genre_id = bouquet.get('id')
                    logging.debug(f"Selected bouquet: {selected}, genre_id: {genre_id}, metadata: {bouquet.get('metadata', {})}")
                    # Ouvrir UStalker_Live_Categories si le module est disponible
                    if LIVE_IMPORTED:
                        self.session.open(UStalker_Live_Categories, self.server, genre_id=genre_id, bouquet_title=selected)
                    else:
                        self["status"].setText("Module Live TV non disponible.")
                except Exception as e:
                    self["status"].setText(f"Erreur ouverture chaînes: {str(e)}")
                    logging.error(f"Error opening UStalker_Live_Categories: {str(e)}", exc_info=True)


class PortalServersScreen(Screen):
    """Écran pour afficher les options du portail Stalker."""
    skin = """
        <screen position="center,center" size="1200,750" backgroundColor="#8b008b" title="Portal Stalker">
            <widget name="serverlist" position="500,200" size="250,550" itemHeight="70" halign="center" backgroundColor="#8b008b" font="Regular;35"/>
            <eLabel text="Select" position="140,660" size="190,40" font="Bold;30" halign="center" valign="center" backgroundColor="green" foregroundColor="white"/>
            <eLabel text="Back" position="380,660" size="190,40" font="Bold;30" halign="center" valign="center" backgroundColor="red" foregroundColor="white"/>
            <eLabel text="Options" position="620,660" size="190,40" font="Bold;30" halign="center" valign="center" backgroundColor="yellow" foregroundColor="white"/>
            <widget name="status" position="100,80" size="1000,50" font="Bold;35" itemHeight="70" backgroundColor="blue" halign="center" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session, server):
        """Initialise l'écran du portail pour un serveur donné."""
        Screen.__init__(self, session)
        self.server = server
        self["serverlist"] = MenuList([])
        self["status"] = Label(f"Connecté : {server.get('SERVER_NAME', 'Serveur Stalker')}")
        self["key_green"] = StaticText("Sélectionner")
        self["key_red"] = StaticText("Retour")
        self["key_yellow"] = StaticText("Options")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.selectItem,
            "green": self.selectItem,
            "yellow": self.showOptions,
            "red": self.close,
            "cancel": self.close
        }, -1)
        self.categories = ["Live TV", "VOD (soon)", "Series (soon)", "Replay (soon)"]
        self.updateList()

    def updateList(self):
        """Met à jour la liste des catégories."""
        self["serverlist"].setList(self.categories)

    def selectItem(self):
        """Ouvre la catégorie sélectionnée."""
        selected = self["serverlist"].getCurrent()
        if selected:
            if selected == "Live TV":
                try:
                    self.session.open(BouquetScreen, self.server)
                except Exception as e:
                    self["status"].setText(f"Erreur ouverture bouquets: {str(e)}")
                    logging.error(f"Error opening BouquetScreen: {str(e)}", exc_info=True)
            else:
                self.session.open(MessageBox, f"Accès à {selected} en cours...", MessageBox.TYPE_INFO)

    def showOptions(self):
        """Affiche le menu des options."""
        menu = [
            ("Actualiser", self.updateList),
            ("Modifier MAC", self.changeMacAddress),
            ("Infos Serveur", self.showServerInfo)
        ]
        self.session.openWithCallback(self.menuCallback, ChoiceBox, title="Options", list=menu)

    def menuCallback(self, choice):
        """Callback pour exécuter l'option sélectionnée."""
        if choice:
            choice[1]()

    def changeMacAddress(self):
        """Ouvre l'écran pour modifier l'adresse MAC."""
        self.session.openWithCallback(self.macAddressChanged, MacAddressInputScreen, self.server.get('ADRESS_MAC', ''))

    def macAddressChanged(self, new_mac):
        """Met à jour l'adresse MAC du serveur."""
        if new_mac:
            self.server['ADRESS_MAC'] = new_mac.upper().replace(':', '')
            servers = load_servers_from_json()
            for s in servers:
                # Comparer les serveurs par SERVER_NAME et SERVER_HOST
                if s.get('SERVER_HOST') == self.server.get('SERVER_HOST') and s.get('SERVER_NAME') == self.server.get('SERVER_NAME'):
                    s['ADRESS_MAC'] = self.server['ADRESS_MAC']
                    break
            if save_servers_to_json(servers):
                self["status"].setText(f"MAC changée: {self.server['ADRESS_MAC']}")
            else:
                self["status"].setText("Erreur sauvegarde MAC!")

    def showServerInfo(self):
        """Affiche les informations du serveur."""
        info = f"""
        Serveur: {self.server.get('SERVER_NAME', 'N/A')}
        URL: {self.server.get('SERVER_HOST', 'N/A')}
        Adresse MAC: {self.server.get('ADRESS_MAC', 'N/A')}
        """
        self.session.open(MessageBox, info, MessageBox.TYPE_INFO)


class EditServerDetailsScreen(ConfigListScreen, Screen):
    """Écran pour configurer les détails d'un serveur Stalker."""
    skin = """
        <screen position="center,center" size="800,600" title="Configurer Serveur">
            <widget name="config" position="20,20" size="760,400" />
            <eLabel text="Save" position="100,500" size="150,40" font="Regular;20" halign="center" valign="center" backgroundColor="green" />
            <eLabel text="Cancel" position="300,500" size="150,40" font="Regular;20" halign="center" valign="center" backgroundColor="red" />
        </screen>
    """

    def __init__(self, session, server=None):
        """Initialise l'écran de configuration du serveur."""
        Screen.__init__(self, session)
        self.server = server or {}
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel
        }, -2)
        # Utiliser le même format que dans plugin.py
        self.name = ConfigText(default=self.server.get("SERVER_NAME", ""), fixed_size=False)
        self.url = ConfigText(default=self.server.get("SERVER_HOST", ""), fixed_size=False)
        self.mac = ConfigText(default=self.server.get("ADRESS_MAC", ""), fixed_size=False)
        self.list = [
            getConfigListEntry("Nom du serveur:", self.name),
            getConfigListEntry("URL serveur:", self.url),
            getConfigListEntry("Adresse MAC:", self.mac)
        ]
        ConfigListScreen.__init__(self, self.list, session=session)

    def save(self):
        """Sauvegarde les détails du serveur après validation."""
        if not self.validate():
            return
        # Utiliser le même format que dans plugin.py
        server = {
            "SERVER_NAME": self.name.value,
            "SERVER_HOST": self.url.value.rstrip('/'),
            "ADRESS_MAC": self.mac.value.upper().replace(':', '')
        }
        self.close(server)

    def validate(self):
        """Valide les entrées du formulaire."""
        if not self.url.value.startswith(('http://', 'https://')):
            self.session.open(MessageBox, "URL doit commencer par http:// ou https://", MessageBox.TYPE_ERROR)
            return False
        if not re.match(r"^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$", self.mac.value):
            self.session.open(MessageBox, "Adresse MAC invalide (format: 00:1A:2B:3C:4D:5E)", MessageBox.TYPE_ERROR)
            return False
        return True

    def cancel(self):
        """Annule la configuration et ferme l'écran."""
        self.close(None)


class MacAddressInputScreen(Screen):
    """Écran pour modifier l'adresse MAC."""
    skin = """
        <screen position="center,center" size="800,200" title="Modifier MAC">
            <widget name="input" position="20,20" size="760,40" font="Regular;28" />
            <eLabel text="OK" position="100,100" size="150,40" font="Regular;20" halign="center" valign="center" backgroundColor="green" />
            <eLabel text="Cancel" position="300,100" size="150,40" font="Regular;20" halign="center" valign="center" backgroundColor="red" />
        </screen>
    """

    def __init__(self, session, current_mac=""):
        """Initialise l'écran de saisie de l'adresse MAC."""
        Screen.__init__(self, session)
        self["input"] = Input(text=current_mac, maxSize=17)
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "green": self.save,
            "red": self.cancel,
            "cancel": self.cancel
        }, -2)

    def save(self):
        """Sauvegarde l'adresse MAC après validation."""
        mac = self["input"].getText()
        if re.match(r"^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$", mac):
            self.close(mac.upper().replace(':', ''))
        else:
            self.session.open(MessageBox, "Format MAC invalide!", MessageBox.TYPE_ERROR)

    def cancel(self):
        """Annule la saisie et ferme l'écran."""
        self.close(None)


def main(session, **kwargs):
    """Ouvre l'écran de gestion des serveurs Stalker."""
    logging.info("Starting StalkerManager")
    session.open(StalkerManagerScreen)


def Plugins(**kwargs):
    """Définit le descripteur du plugin pour Enigma2."""
    from Plugins.Plugin import PluginDescriptor  # Importer ici pour éviter les problèmes potentiels
    return [PluginDescriptor(
        name="Stalker Manager",
        description="Gestion des portails Stalker",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main
    )]



